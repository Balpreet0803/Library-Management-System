import javax.swing.*;
import java.awt.*;

public class About extends JPanel{
    
    public About(){
        
        ImageIcon icon = new ImageIcon(ClassLoader.getSystemResource("images/java.jpg"));
        
        //Create Lable and ImageIcon setting
        
        JLabel lbl = new JLabel(icon);
        //add Label to the Panel
        this.add(lbl);
        
       
                
    }
}
